import pandas as pd
import matplotlib.pyplot as plt
from wordcloud import WordCloud


def generate_visualizations(df: pd.DataFrame) -> None:
    """生成分析图表"""
    _generate_sentiment_chart(df)
    _generate_wordcloud(df)
    _generate_price_comparison(df)


def _generate_sentiment_chart(df: pd.DataFrame) -> None:
    """生成情感得分柱状图"""
    plt.figure(figsize=(12, 6))
    plt.bar(df["name"], df["sentiment_score"], color="skyblue")
    plt.title("路由器情感得分对比")
    plt.xlabel("产品名称")
    plt.ylabel("情感得分")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig("sentiment_scores.png")
    print("情感得分图表已生成")


def _generate_wordcloud(df: pd.DataFrame) -> None:
    """生成优点词云图"""
    all_positive_tags = " ".join(df["positive_tags"].str.split(",").explode().dropna())
    wordcloud = WordCloud(font_path="simhei.ttf", width=800, height=400).generate(all_positive_tags)

    plt.figure(figsize=(12, 6))
    plt.imshow(wordcloud, interpolation="bilinear")
    plt.axis("off")
    plt.title("高频优点关键词云")
    plt.tight_layout()
    plt.savefig("positive_tags.png")
    print("优点词云图已生成")


def _generate_price_comparison(df: pd.DataFrame) -> None:
    """生成价格对比图"""
    plt.figure(figsize=(12, 6))
    plt.bar(df["name"], df["price"], color="lightgreen")
    plt.title("路由器价格对比")
    plt.xlabel("产品名称")
    plt.ylabel("价格 (元)")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig("price_comparison.png")
    print("价格对比图表已生成")