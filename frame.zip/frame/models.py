class ProductInfo:
    """产品信息数据模型"""
    def __init__(self, platform, merchant_id, name, price, reviews, wifi_version, speed):
        self.platform = platform
        self.merchant_id = merchant_id
        self.name = name
        self.price = price
        self.reviews = reviews
        self.wifi_version = wifi_version
        self.speed = speed

    def to_dict(self):
        return {
            "platform": self.platform,
            "merchant_id": self.merchant_id,
            "name": self.name,
            "price": self.price,
            "reviews": self.reviews,
            "wifi_version": self.wifi_version,
            "speed": self.speed
        }