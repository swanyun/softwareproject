from crawler import crawl_data
from analyzer import clean_and_analyze
from storage import save_to_database
from visualizer import generate_visualizations

def main():
    # 1. 数据爬取
    print("开始爬取数据...")
    raw_data = crawl_data()
    print(f"成功爬取 {len(raw_data)} 条产品数据")

    # 2. 数据清洗和文本分析
    print("开始数据清洗和分析...")
    analyzed_df = clean_and_analyze(raw_data)
    print(f"数据处理完成，剩余 {len(analyzed_df)} 条有效数据")

    # 3. 数据存储
    print("开始存储数据...")
    save_to_database(analyzed_df)

    # 4. 可视化
    print("开始生成可视化图表...")
    generate_visualizations(analyzed_df)
    print("所有任务已完成")


if __name__ == "__main__":
    main()