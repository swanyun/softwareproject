import requests
from bs4 import BeautifulSoup
from models import ProductInfo
from config import CONFIG
import re


def crawl_data() -> list[ProductInfo]:
    """爬取并返回产品信息列表"""
    jd_data = _crawl_jd()
    tmall_data = _crawl_tmall()
    return jd_data + tmall_data


def _crawl_jd() -> list[ProductInfo]:
    """爬取京东平台数据"""
    headers = {"User-Agent": CONFIG["USER_AGENT"]}
    try:
        response = requests.get(CONFIG["JD_URL"], headers=headers)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        products = soup.find_all("li", class_="gl-item")

        return [_parse_jd_product(product) for product in products]
    except Exception as e:
        print(f"爬取京东数据失败: {e}")
        return []


def _parse_jd_product(product) -> ProductInfo:
    """解析单个京东商品"""
    name = product.find("div", class_="p-name").a.em.get_text(strip=True)
    price = float(product.find("div", class_="p-price").i.get_text(strip=True))
    reviews = [review.get_text(strip=True) for review in product.find_all("div", class_="p-commit")]
    merchant_id = "JD_" + product.get("data-sku", "unknown")

    return ProductInfo(
        platform="JD",
        merchant_id=merchant_id,
        name=name,
        price=price,
        reviews=reviews,
        wifi_version=_extract_wifi_version(name),
        speed=_extract_speed(name)
    )


def _crawl_tmall() -> list[ProductInfo]:
    """爬取天猫平台数据"""
    headers = {"User-Agent": CONFIG["USER_AGENT"]}
    try:
        response = requests.get(CONFIG["TMALL_URL"], headers=headers)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        products = soup.find_all("div", class_="product-iWrap")

        return [_parse_tmall_product(product) for product in products]
    except Exception as e:
        print(f"爬取天猫数据失败: {e}")
        return []


def _parse_tmall_product(product) -> ProductInfo:
    """解析单个天猫商品"""
    name = product.find("div", class_="productTitle").a.get_text(strip=True)
    price_text = product.find("p", class_="productPrice").em.get_text(strip=True)
    price = float(re.sub(r'[^\d.]', '', price_text))
    review_element = product.find("div", class_="productReview")
    reviews = [review_element.span.get_text(strip=True)] if review_element else []
    merchant_id = "TMALL_" + product.get("data-id", "unknown")

    return ProductInfo(
        platform="TMALL",
        merchant_id=merchant_id,
        name=name,
        price=price,
        reviews=reviews,
        wifi_version=_extract_wifi_version(name),
        speed=_extract_speed(name)
    )


def _extract_wifi_version(name: str) -> str:
    """从名称中提取WIFI版本"""
    if "WIFI6E" in name or "WiFi6E" in name:
        return "WIFI6E"
    elif "WIFI6" in name or "WiFi6" in name or "AX" in name:
        return "WIFI6"
    elif "WIFI5" in name or "WiFi5" in name or "AC" in name:
        return "WIFI5"
    else:
        return "未知"


def _extract_speed(name: str) -> str:
    """从名称中提取无线速率"""
    match = re.search(r'(\d+M)', name)
    return match.group(1) if match else "未知"