CONFIG = {
    "JD_URL": "https://search.jd.com/Search?keyword=WIFI6路由器",# 京东搜索URL
    "TMALL_URL": "https://list.tmall.com/search_product.htm?q=WIFI6路由器",# 天猫搜索URL
    "USER_AGENT": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36", # 模拟浏览器请求头，防止被反爬
    "DB_CONFIG": { # 数据库连接配置
        "host": "localhost",
        "user": "your_username",
        "password": "your_password",
        "database": "router_db",
        "charset": "utf8mb4"# 支持完整中文和表情符号
    },
    # 正面和负面评价关键词
    "POSITIVE_KEYWORDS": {"信号强", "速度快", "稳定", "穿墙好", "覆盖广", "易设置", "颜值高"},
    "NEGATIVE_KEYWORDS": {"断流", "发热", "信号差", "速度慢", "难设置", "性价比低", "不稳定"}
}