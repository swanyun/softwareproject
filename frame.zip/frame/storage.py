import pandas as pd
import pymysql
from config import CONFIG


def save_to_database(df: pd.DataFrame) -> None:
    """将分析后的数据存入数据库"""
    try:
        conn = pymysql.connect(**CONFIG["DB_CONFIG"])
        cursor = conn.cursor()

        insert_sql = """
            INSERT INTO router_evaluation 
            (merchant_id, product_name, platform, price, wifi_version, speed, positive_tags, negative_tags, sentiment_score)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE 
            price=VALUES(price), 
            sentiment_score=VALUES(sentiment_score)
        """

        for _, row in df.iterrows():
            cursor.execute(insert_sql, (
                row["merchant_id"],
                row["name"],
                row["platform"],
                row["price"],
                row["wifi_version"],
                row["speed"],
                row["positive_tags"],
                row["negative_tags"],
                row["sentiment_score"]
            ))

        conn.commit()
        conn.close()
        print("数据已成功存入数据库")
    except Exception as e:
        print(f"存储数据失败: {e}")