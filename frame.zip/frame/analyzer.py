import pandas as pd
import jieba
from collections import defaultdict
from models import ProductInfo
from config import CONFIG


def clean_and_analyze(raw_data: list[ProductInfo]) -> pd.DataFrame:
    """执行数据清洗和文本分析"""
    cleaned_df = _clean_data(raw_data)
    analyzed_df = _analyze_reviews(cleaned_df)
    return analyzed_df


def _clean_data(raw_data: list[ProductInfo]) -> pd.DataFrame:
    """清洗原始数据"""
    data_list = [p.to_dict() for p in raw_data]
    df = pd.DataFrame(data_list)

    # 数据去重和过滤
    df = df.drop_duplicates(subset="name", keep="first")
    df = df[df["reviews"].apply(len) > 0]

    return df


def _analyze_reviews(df: pd.DataFrame) -> pd.DataFrame:
    """分析用户评价"""
    jieba.load_userdict("router_terms.txt")

    def process_review(reviews):
        positive_tags = defaultdict(int)
        negative_tags = defaultdict(int)

        for review in reviews:
            words = jieba.lcut(review)
            for word in words:
                if word in CONFIG["POSITIVE_KEYWORDS"]:
                    positive_tags[word] += 1
                elif word in CONFIG["NEGATIVE_KEYWORDS"]:
                    negative_tags[word] += 1

        top_positive = [k for k, v in sorted(positive_tags.items(), key=lambda x: -x[1])[:2]]
        top_negative = [k for k, v in sorted(negative_tags.items(), key=lambda x: -x[1])[:2]]

        return {
            "positive_tags": ",".join(top_positive),
            "negative_tags": ",".join(top_negative),
            "sentiment_score": (sum(positive_tags.values()) - sum(negative_tags.values())) / max(1, len(reviews))
        }

    df[["positive_tags", "negative_tags", "sentiment_score"]] = df["reviews"].apply(process_review).apply(pd.Series)
    return df